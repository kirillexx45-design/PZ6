package main

import (
	"fmt"
	"sync"
	"time"
)

var count int
var mu sync.Mutex

func Z1() {
	var wg sync.WaitGroup

	for i := 0; i < 100; i++ {

		wg.Add(1)

		go func() {
			defer wg.Done()
			mu.Lock()
			count++
			mu.Unlock()
			fmt.Printf("Горутина %d; Счет: %d\n", i+1, count)
		}()
		time.Sleep(time.Millisecond * 200)
	}

	wg.Wait()
}
