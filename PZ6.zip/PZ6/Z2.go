package main

import (
	"fmt"
	"sync"
	"time"
)

type cache struct {
	mu   sync.RWMutex
	data map[string]int
}

func (c *cache) Get(k string) (int, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	v, ok := c.data[k]
	return v, ok
}

func (c *cache) Set(k string, v int) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.data[k] = v
}

func Z2() {

	c := &cache{
		data: map[string]int{"users": 10},
	}
	var wg sync.WaitGroup

	for i := 0; i < 3; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			v, _ := c.Get("users")
			fmt.Println("читатель", id, "увидел", v)
		}(i)
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		time.Sleep(100 * time.Millisecond)
		c.Set("users", 99)
		fmt.Println("писатель обновил на 99")
	}()
	wg.Wait()
}
