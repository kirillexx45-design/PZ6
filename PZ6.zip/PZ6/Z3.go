package main

import (
	"fmt"
	"sync"
)

type Task struct {
	ID int
}

type TaskRead struct {
	mu    sync.Mutex
	tasks []Task
}

func (R *TaskRead) Pop() (Task, bool) {
	mu.Lock()
	defer mu.Unlock()

	if len(R.tasks) == 0 {
		return Task{}, false
	}

	task := R.tasks[0]
	R.tasks = R.tasks[1:]
	return task, true
}

func Z3() {

	v := TaskRead{}
	var wg sync.WaitGroup

	for i := 0; i < 10; i++ {
		v.tasks = append(v.tasks, Task{ID: i})
	}

	for i := 0; i < 5; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				task, ok := v.Pop()
				if !ok {
					break
				}
				fmt.Printf("Обработана задача %d:", task.ID)
			}
		}()
	}
	wg.Wait()
}
