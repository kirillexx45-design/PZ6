package main

import (
	"fmt"
	"sync"
)

func Z11() {

	const (
		totalSeats = 38
		Users      = 100
	)

	seats := make([]int, totalSeats)

	var mu sync.Mutex
	var wg sync.WaitGroup

	for idUser := 0; idUser <= totalSeats; idUser++ {

		wg.Add(1)

		go func(Rid int) {
			defer wg.Done()
			want := Rid % totalSeats
			mu.Lock()
			if seats[want] != 0 {
				fmt.Printf("Пользователь %2d: место %2d ЗАНЯТО (был %d)\n",
					Rid, want+1, seats[want])
				mu.Unlock()
				return
			}
			seats[want] = Rid
			fmt.Printf("Пользователь %2d: ЗАБРОНИРОВАЛ место %2d\n", Rid, want+1)
			mu.Unlock()
		}(idUser)

	}
	wg.Wait()

	itog := 0
	for _, w := range seats {
		if w != 0 {
			itog++
		}
	}
	fmt.Printf("\nЗабронировано: %d из %d мест\n", itog, totalSeats)
}
