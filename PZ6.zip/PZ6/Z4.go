package main

import (
	"fmt"
	"sync"
	"time"
)

func Z4() {

	var (
		mu    sync.Mutex
		count = map[string]int{}
		wg    sync.WaitGroup
	)

	votes := make(chan string)

	go func() {
		for i := 0; i < 1000; i++ {
			votes <- []string{"Кирилл", "Егор", "Андрей"}[i%3]
			time.Sleep(time.Millisecond)
		}
		close(votes)
	}()

	for i := 0; i < 5; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for v := range votes {
				mu.Lock()
				count[v]++
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	fmt.Println(count)
}
