package main

import (
	"fmt"
	"sync"
)

type Store struct {
	sync.Mutex
	m map[string]int
}

func (s *Store) Add(k string, n int) {
	s.Lock()
	defer s.Unlock()
	s.m[k] += n
}

func (s *Store) Sell(k string, n int) int {
	s.Lock()
	defer s.Unlock()
	if s.m[k] < n {
		n = s.m[k]
	}
	s.m[k] -= n
	return n
}

func Z7() {

	s := Store{m: map[string]int{}}

	var wg sync.WaitGroup

	for i := 0; i < 10; i++ {
		wg.Add(2)
		go func() {
			defer wg.Done()
			s.Add("Банан", 5)
		}()
		go func() {
			defer wg.Done()
			s.Sell("Банан", 3)
		}()
	}
	wg.Wait()

	s.Lock()
	fmt.Println(s.m["Банан"])
	s.Unlock()

}
