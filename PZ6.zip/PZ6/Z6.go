package main

import (
	"fmt"
	"sync"
	"time"
)

func Z6() {

	var mu sync.Mutex
	var wg sync.WaitGroup

	for i := 0; i < 5; i++ {

		wg.Add(1)

		go func(id int) {
			defer wg.Done()
			for j := 0; j < 3; j++ {
				mu.Lock()
				fmt.Printf("goroutine %d: message %d\n", id, j)
				mu.Unlock()
				time.Sleep(time.Millisecond * 100)
			}
		}(i)

	}
	wg.Wait()
}
